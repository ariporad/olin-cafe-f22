int a_global_variable = 12;
int FACTORIAL_BASE_CASE = 1;

int factorial(int n)
{
    static int factorial_count = 0;
    factorial_count += 1;

    a_global_variable += n;

    if (n <= 0)
    {
        return FACTORIAL_BASE_CASE;
    }

    return n * factorial(n - 1);
}

int main(int n)
{
    return factorial(n);
}
